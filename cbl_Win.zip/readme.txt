cbl.exe
Console Based note & clips Lookup & retrieval

Run setup.cmd as administrator (powershell)

Store text files on c:\Users\NAME\cbl\

See "tkinter.txt" as example of text file.

Format of text file:

    item ^_^

    many lines of text ...
    clip or information ...

    item ^_^

    many lines of text ...
    clip or information ...

    item ^_^

    many lines of text ...
    clip or information ...

    item ^_^

    many lines of text ...
    clip or information ...

    etc...


    "item" should be a single "word" with no spaces

    text file name should be descriptive of information and
    easy to type and remember.


USAGE:

1. display all of your created text files:
$> cbl

2. display all topics/items in particular text file:
$> cbl tkinter

3. display all lines for topic/item in particular text file:
$> cbl tkinter spinbutton

4. display all topics and lines containing some text in particular text file:
$> cbl tkinter sea "bind(<"
	NOTE: s sea search all the same

	

