#!/bin/bash
gcc -O1 -w -o $1 $1.c
