cbl.exe
Console Based note & clips Lookup & retrieval

Run setup.cmd as administrator (powershell)

Store text files on c:\Users\NAME\cbl\

See "tkinter.txt" as example of text file.

Format of text file:

    item ^_^

    many lines of text ...
    clip or information ...

    item ^_^

    many lines of text ...
    clip or information ...

    item ^_^

    many lines of text ...
    clip or information ...

    item ^_^

    many lines of text ...
    clip or information ...

    etc...


    "item" should be a single "word" with no spaces

    text file name should be descriptive of information and
    easy to type and remember.
